DEBUG = False

# Saving and loading responses from text files so that you do not have to do multiple requests when debugging.
DEBUG_STORAGE = False

# PROXY = ''

# STATS_HEADERS = {}
